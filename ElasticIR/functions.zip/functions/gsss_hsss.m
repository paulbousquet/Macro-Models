% GSSS_HSSS.M
% This program finds the 1-dimensional arrays gsss and hsss necessary to compute the 3rd order approximation to the decision rules of a DSGE model of the form 
% E_tf(yp,y,xp,x)=0, with solution xp=h(x,sigma) + sigma * eta * ep and y=g(x,sigma). 
% INPUTS: First, second and third order derivatives of f and first- and second-order approximations to the functions g and h
% OUTPUTS: Third-order derivatives of the functions g and h with respect to sigma, evaluated at (x,sigma)=(xbar,0), where xbar=h(xbar,0).

%(c) Francisco Ruge-Murcia (July 2006)
% In September 2010, the way Term 10 is computed was changed.
% This change generalizes the code to models with more than one structural shock


function [gsss,hsss] = gsss_hsss(fx,fxp,fy,fyp,fypyp,fypy,fypxp,fypx,fyyp,fyy,fyxp,fyx,fxpyp,fxpy,fxpxp,fxpx,fxyp,fxy,fxxp,fxx,...
    fypypyp,fypypy,fypypxp,fypypx,fypyyp,fypyy,fypyxp,fypyx,fypxpyp,fypxpy,fypxpxp,fypxpx,fypxyp,fypxy,fypxxp,fypxx,...
    fyypyp,fyypy,fyypxp,fyypx,fyyyp,fyyy,fyyxp,fyyx,fyxpyp,fyxpy,fyxpxp,fyxpx,fyxyp,fyxy,fyxxp,fyxx,...
    fxpypyp,fxpypy,fxpypxp,fxpypx,fxpyyp,fxpyy,fxpyxp,fxpyx,fxpxpyp,fxpxpy,fxpxpxp,fxpxpx,fxpxyp,fxpxy,fxpxxp,fxpxx,...
    fxypyp,fxypy,fxypxp,fxypx,fxyyp,fxyy,fxyxp,fxyx,fxxpyp,fxxpy,fxxpxp,fxxpx,fxxyp,fxxy,fxxxp,fxxx,...
    hx,gx,hxx,gxx,gxxx,gss,hss,esk)
                                

nx = size(hx,1); % rows of hx, hxx and hxx
ny = size(gx,1); % rows of gx, gxx and gxx
n = nx + ny; % length of f
ne = size(esk,2); %number of exogenous shocks (columns of esk)


% COMPUTE CONSTANT TERMS
q = zeros(n,1); % array with constant terms

for i=1:n
    for k = 1:ne
        % Term 1
        tfc = reshape(fypypyp,n,ny,ny,ny);
        t=1;
        for t=1:ny;
            if t==1;
                tmat=((reshape(tfc(i,t,:,:),ny,ny)) * gx * esk(:,k));
             else
                tmat=[tmat ((reshape(tfc(i,t,:,:),ny,ny)) * gx * esk(:,k))];
             end
        end
        q(i)= q(i) + (tmat' * gx * esk(:,k))' * gx * esk(:,k);
   
        % Term 2
        tfc = reshape(fypypxp,n,ny,ny,nx);
        t=1;
        for t=1:ny;
            if t==1;
                 tmat=reshape(tfc(i,t,:,:),ny,nx) * esk(:,k);
             else
                 tmat=[tmat (reshape(tfc(i,t,:,:),ny,nx) * esk(:,k))];
             end
        end
        q(i)= q(i) + ((tmat'* gx * esk(:,k))' * gx * esk(:,k));
        
       % Term 3
       tfc = reshape(fypyp,n,ny,ny);
       t=1;
       for t=1:ny;
            if t==1;
                 tmat=(reshape(gxx(t,:,:),nx,nx)) * esk(:,k);
             else
                 tmat=[tmat ((reshape(gxx(t,:,:),nx,nx)) * esk(:,k))];
             end
        end
        tmat = tmat' * esk(:,k);
        q(i)= q(i) + (reshape(tfc(i,:,:),ny,ny) * tmat)' * gx * esk(:,k);
        
       % Term 4
        tfc = reshape(fypyp,n,ny,ny);
        t=1;
        for t=1:ny;
            if t==1;
                 tmat=(reshape(gxx(t,:,:),nx,nx)) * esk(:,k);
             else
                 tmat=[tmat ((reshape(gxx(t,:,:),nx,nx)) * esk(:,k))];
             end
        end
        tmat = tmat' * esk(:,k);
        q(i)= q(i) + (reshape(tfc(i,:,:),ny,ny) * gx * esk(:,k))' * tmat;                
        
        % Term 5
        tfc = reshape(fypxpyp,n,ny,nx,ny);
        t=1;
        for t=1:ny;
            if t==1;
                tmat=(reshape(tfc(i,t,:,:),nx,ny)) * gx * esk(:,k);
             else
                tmat=[tmat ((reshape(tfc(i,t,:,:),nx,ny)) * gx * esk(:,k))];
             end
        end
        q(i)= q(i) + (tmat' * esk(:,k))' * gx * esk(:,k);

        % Term 6
        tfc = reshape(fypxpxp,n,ny,nx,nx);
        t=1;
        for t=1:ny;
            if t==1;
                tmat=(reshape(tfc(i,t,:,:),nx,nx)) * esk(:,k);
             else
                tmat=[tmat ((reshape(tfc(i,t,:,:),nx,nx)) * esk(:,k))];
             end
        end
        q(i)= q(i) + (tmat' * esk(:,k))' * gx * esk(:,k);
        
        % Term 7
        tfc = reshape(fypxp,n,ny,nx);
        t=1;
        for t=1:ny;
            if t==1;
                 tmat=(reshape(gxx(t,:,:),nx,nx)) * esk(:,k);
             else
                 tmat=[tmat ((reshape(gxx(t,:,:),nx,nx)) * esk(:,k))];
             end
        end
        tmat = tmat' * esk(:,k);
        q(i)= q(i) + (reshape(tfc(i,:,:),ny,nx) * esk(:,k))' * tmat;
        
        % Term 8
        tfc = reshape(fypyp,n,ny,ny);
        t=1;
        for t=1:ny;
            if t==1;
                 tmat=(reshape(gxx(t,:,:),nx,nx)) * esk(:,k);
             else
                 tmat=[tmat ((reshape(gxx(t,:,:),nx,nx)) * esk(:,k))];
             end
        end
        tmat = tmat' * esk(:,k);
        q(i)= q(i) + (reshape(tfc(i,:,:),ny,ny) * gx * esk(:,k))' * tmat;

        % Term 9
        tfc = reshape(fypxp,n,ny,nx);
        t=1;
        for t=1:ny;
            if t==1;
                 tmat=(reshape(gxx(t,:,:),nx,nx)) * esk(:,k);
             else
                 tmat=[tmat ((reshape(gxx(t,:,:),nx,nx)) * esk(:,k))];
             end
        end
        tmat = tmat' * esk(:,k);
        q(i)= q(i) + (reshape(tfc(i,:,:),ny,nx) * esk(:,k))' * tmat;

       % Term 10
       tfc = reshape(fyp,n,ny);
       t = 1;
       for t=1:ny;
           m=1;
           for m=1:nx;
               if m==1;
                   tmat=((reshape(gxxx(t,m,:,:),nx,nx)) * esk(:,k));
               else
                   tmat=[tmat ((reshape(gxxx(t,m,:,:),nx,nx)) * esk(:,k))];
               end
           end
           if t==1;
               bmat = shiftdim(tmat,-1);  
           else
               bmat = [bmat; shiftdim(tmat,-1)];
           end              
       end
       for t=1:ny;
            if t==1;
                 tmat=(reshape(bmat(t,:,:),nx,nx)) * esk(:,k);
             else
                 tmat=[tmat ((reshape(bmat(t,:,:),nx,nx)) * esk(:,k))];
             end
       end
       tmat = tmat' * esk(:,k);
       q(i)= q(i) + (reshape(tfc(i,:),ny,1))' * tmat;
            
       % Term 11
        tfc = reshape(fxpypyp,n,nx,ny,ny);
        t=1;
        for t=1:nx;
            if t==1;
                tmat=((reshape(tfc(i,t,:,:),ny,ny)) * gx * esk(:,k));
             else
                tmat=[tmat ((reshape(tfc(i,t,:,:),ny,ny)) * gx * esk(:,k))];
             end
        end
        q(i)= q(i) + (tmat' * gx * esk(:,k))' * esk(:,k);
        
        % Term 12
        tfc = reshape(fxpypxp,n,nx,ny,nx);
        t=1;
        for t=1:nx;
            if t==1;
                tmat=((reshape(tfc(i,t,:,:),ny,nx)) * esk(:,k));
             else
                tmat=[tmat ((reshape(tfc(i,t,:,:),ny,nx)) * esk(:,k))];
             end
        end
        q(i)= q(i) + (tmat' * gx * esk(:,k))' * esk(:,k);

        % Term 13
        tfc = reshape(fxpyp,n,nx,ny);
        t=1;
        for t=1:ny;
             if t==1;
                 tmat=(reshape(gxx(t,:,:),nx,nx)) * esk(:,k);
             else
                 tmat=[tmat ((reshape(gxx(t,:,:),nx,nx)) * esk(:,k))];
             end
        end
        tmat = tmat' * esk(:,k);
        q(i)= q(i) + (reshape(tfc(i,:,:),nx,ny) * tmat)' * esk(:,k);

        % Term 14
        tfc = reshape(fxpxpyp,n,nx,nx,ny);
        t=1;
        for t=1:nx;
            if t==1;
                 tmat=reshape(tfc(i,t,:,:),nx,ny) * gx * esk(:,k);
             else
                 tmat=[tmat (reshape(tfc(i,t,:,:),nx,ny) * gx * esk(:,k))];
             end
        end
        q(i)= q(i) + ((tmat'* esk(:,k))' * esk(:,k));

        % Term 15
        tfc = reshape(fxpxpxp,n,nx,nx,nx);
        t=1;
        for t=1:nx;
            if t==1;
                 tmat=reshape(tfc(i,t,:,:),nx,nx) * esk(:,k);
             else
                 tmat=[tmat (reshape(tfc(i,t,:,:),nx,nx) * esk(:,k))];
             end
        end
        q(i)= q(i) + (tmat'* esk(:,k))' * esk(:,k);
    end
end


% COMPUTE COEFFICIENTS OF GSSS AND HSSS
ngsss = ny; % elements of gsss
nhsss = nx; % elements of hsss
sg = [ny 1]; %size of gsss
sh = [nx 1]; %size of hsss

Q = zeros(nx,ngsss+nhsss);

gsss=zeros(sg);
hsss=zeros(sh);
GSSS=zeros(sg);
HSSS=zeros(sh);

t = 0;
for i=1:n
    t = t+1;
    GSSS(:)=fyp(i,:)';
    Q(t,1:ngsss) = GSSS(:)';
    GSSS = 0*GSSS;

    HSSS(:,1) = (fyp(i,:) * gx)';
    Q(t,ngsss+1:end)=HSSS(:)';
    HSSS = 0*HSSS;

    GSSS(:,1)=fy(i,:)';
    Q(t,1:ngsss) = Q(t,1:ngsss) + GSSS(:)';
    GSSS = 0*GSSS;

    HSSS(:,1)=fxp(i,:)';
    Q(t,ngsss+1:end) = Q(t,ngsss+1:end) + HSSS(:)';
    HSSS = 0*HSSS;                    
end


% SOLVE FOR THIRD-ORDER COEFFICIENTS
cc = -Q\q;
gsss(:)=cc(1:ngsss);
hsss(:) = cc(ngsss+1:end);


