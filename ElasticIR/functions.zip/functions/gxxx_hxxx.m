% GXXX_HXXX.M
% This program finds the 4-dimensional arrays gxxx and hxxx necessary to compute the 3rd order approximation to the decision rules of a DSGE model of the form 
% E_tf(yp,y,xp,x)=0, with solution xp=h(x,sigma) + sigma * eta * ep and y=g(x,sigma). 
% INPUTS: First, second and third order derivatives of f and first- and second-order approximations to the functions g and h
% OUTPUTS: Third-order derivatives of the functions g and h with respect to x, evaluated at (x,sigma)=(xbar,0), where xbar=h(xbar,0). 

%(c) Francisco Ruge-Murcia (July 2006)
% In September 2010, changes were made to the companion programs GSSS_HSSS.M and % GXSS_HXSS.M


function [gxxx,hxxx] = gxxx_hxxx(fx,fxp,fy,fyp,fypyp,fypy,fypxp,fypx,fyyp,fyy,fyxp,fyx,fxpyp,fxpy,fxpxp,fxpx,fxyp,fxy,fxxp,fxx,...
    fypypyp,fypypy,fypypxp,fypypx,fypyyp,fypyy,fypyxp,fypyx,fypxpyp,fypxpy,fypxpxp,fypxpx,fypxyp,fypxy,fypxxp,fypxx,...
    fyypyp,fyypy,fyypxp,fyypx,fyyyp,fyyy,fyyxp,fyyx,fyxpyp,fyxpy,fyxpxp,fyxpx,fyxyp,fyxy,fyxxp,fyxx,...
    fxpypyp,fxpypy,fxpypxp,fxpypx,fxpyyp,fxpyy,fxpyxp,fxpyx,fxpxpyp,fxpxpy,fxpxpxp,fxpxpx,fxpxyp,fxpxy,fxpxxp,fxpxx,...
    fxypyp,fxypy,fxypxp,fxypx,fxyyp,fxyy,fxyxp,fxyx,fxxpyp,fxxpy,fxxpxp,fxxpx,fxxyp,fxxy,fxxxp,fxxx,...
    hx,gx,hxx,gxx)
                                

nx = size(hx,1); % rows of hx, hxx and hxx
ny = size(gx,1); % rows of gx, gxx and gxx
n = nx + ny; % length of f


% COMPUTE CONSTANT TERMS
q = zeros(n,nx,nx,nx); % array with constant terms

for i=1:n
    for j=1:nx
        %for k=1:nx
        for k = 1:j    
            for m=1:nx
                % Term 1
                tfc = reshape(fypypyp,n,ny,ny,ny);
                t=1;
                for t=1:ny;
                    if t==1;
                        tmat=(reshape(tfc(i,t,:,:),ny,ny)) * gx * hx(:,m);
                     else
                        tmat=[tmat ((reshape(tfc(i,t,:,:),ny,ny)) * gx * hx(:,m))];
                     end
                end
                q(i,j,k,m) = (tmat'* gx * hx(:,k))' * gx * hx(:,j);
           
                % Term 2
                tfc = reshape(fypypy,n,ny,ny,ny);
                t=1;
                for t=1:ny;
                    if t==1;
                         tmat=(reshape(tfc(i,t,:,:),ny,ny)) * gx(:,m);
                     else
                         tmat=[tmat ((reshape(tfc(i,t,:,:),ny,ny)) * gx(:,m))];
                     end
                end
                q(i,j,k,m)= q(i,j,k,m) + (tmat'* gx * hx(:,k))' * gx * hx(:,j);

                % Term 3
                tfc = reshape(fypypxp,n,ny,ny,nx);
                t=1;
                for t=1:ny;
                    if t==1;
                         tmat=(reshape(tfc(i,t,:,:),ny,nx)) * hx(:,m);
                     else
                         tmat=[tmat ((reshape(tfc(i,t,:,:),ny,nx)) * hx(:,m))];
                     end
                end
                q(i,j,k,m)= q(i,j,k,m) + ((tmat'* gx * hx(:,k))' * gx * hx(:,j));
                
                % Term 4
                tfc = reshape(fypypx,n,ny,ny,nx);
                t=1;
                for t=1:ny;
                    if t==1;
                         tmat=(reshape(tfc(i,t,:,m),ny,1));
                     else
                         tmat=[tmat ((reshape(tfc(i,t,:,m),ny,1)))];
                     end
                end
               q(i,j,k,m)= q(i,j,k,m) + ((tmat'* gx * hx(:,k))' * gx * hx(:,j));
               
               % Term 5
               tfc = reshape(fypyp,n,ny,ny);
               t=1;
               for t=1:ny;
                    if t==1;
                         tmat=(reshape(gxx(t,:,:),nx,nx)) * hx(:,m);
                     else
                         tmat=[tmat ((reshape(gxx(t,:,:),nx,nx)) * hx(:,m))];
                     end
                end
                tmat = tmat' * hx(:,k);
                q(i,j,k,m)= q(i,j,k,m) + (reshape(tfc(i,:,:),ny,ny) * tmat)' * gx * hx(:,j);
                
                % Term 6
                tfc = reshape(fypyp,n,ny,ny);
                q(i,j,k,m)= q(i,j,k,m) + (reshape(tfc(i,:,:),ny,ny) * gx * hxx(:,k,m))' * gx * hx(:,j);

                % Term 7
                tfc = reshape(fypyp,n,ny,ny);
                t=1;
                for t=1:ny;
                    if t==1;
                         tmat=(reshape(gxx(t,:,:),nx,nx)) * hx(:,m);
                     else
                         tmat=[tmat ((reshape(gxx(t,:,:),nx,nx)) * hx(:,m))];
                     end
                end
                tmat = tmat' * hx(:,j);
                q(i,j,k,m)= q(i,j,k,m) + (reshape(tfc(i,:,:),ny,ny) * gx * hx(:,k))' * tmat;
                
                % Term 8
                tfc = reshape(fypyp,n,ny,ny);
                q(i,j,k,m)= q(i,j,k,m) + (reshape(tfc(i,:,:),ny,ny) * gx * hx(:,k))' * gx * hxx(:,j,m);
                
                % Term 9
                tfc = reshape(fypyyp,n,ny,ny,ny);
                t=1;
                for t=1:ny;
                    if t==1;
                        tmat=(reshape(tfc(i,t,:,:),ny,ny)) * gx * hx(:,m);
                     else
                        tmat=[tmat ((reshape(tfc(i,t,:,:),ny,ny)) * gx * hx(:,m))];
                     end
                end
                q(i,j,k,m)= q(i,j,k,m) + (tmat'* gx(:,k))' * gx * hx(:,j);

                % Term 10
                tfc = reshape(fypyy,n,ny,ny,ny);
                t=1;
                for t=1:ny;
                    if t==1;
                        tmat=(reshape(tfc(i,t,:,:),ny,ny)) * gx(:,m);
                     else
                        tmat=[tmat ((reshape(tfc(i,t,:,:),ny,ny)) * gx(:,m))];
                     end
                end
                q(i,j,k,m)= q(i,j,k,m) + (tmat'* gx(:,k))' * gx * hx(:,j);

                % Term 11
                tfc = reshape(fypyxp,n,ny,ny,nx);
                t=1;
                for t=1:ny;
                    if t==1;
                        tmat=(reshape(tfc(i,t,:,:),ny,nx)) * hx(:,m);
                     else
                        tmat=[tmat ((reshape(tfc(i,t,:,:),ny,nx)) * hx(:,m))];
                     end
                end
                q(i,j,k,m)= q(i,j,k,m) + (tmat'* gx(:,k))' * gx * hx(:,j);

                % Term 12
                tfc = reshape(fypyx,n,ny,ny,nx);
                q(i,j,k,m)= q(i,j,k,m) + (reshape(tfc(i,:,:,m),ny,ny)* gx(:,k))' * gx * hx(:,j);
 
                % Term 13
                tfc = reshape(fypy,n,ny,ny);
                q(i,j,k,m)= q(i,j,k,m) + (reshape(tfc(i,:,:),ny,ny) * gxx(:,k,m))' * gx * hx(:,j);
                
                % Term 14
                tfc = reshape(fypy,n,ny,ny);
                t=1;
                for t=1:ny;
                    if t==1;
                         tmat=(reshape(gxx(t,:,:),nx,nx)) * hx(:,m);
                     else
                         tmat=[tmat ((reshape(gxx(t,:,:),nx,nx)) * hx(:,m))];
                     end
                end
                tmat = tmat' * hx(:,j);
                q(i,j,k,m)= q(i,j,k,m) + (reshape(tfc(i,:,:),ny,ny) * gx(:,k))' * tmat;
                
                % Term 15
                tfc = reshape(fypy,n,ny,ny);
                q(i,j,k,m)= q(i,j,k,m) + (reshape(tfc(i,:,:),ny,ny) * gx(:,k))' * gx * hxx(:,j,m);
                
                % Term 16
                tfc = reshape(fypxpyp,n,ny,nx,ny);
                t=1;
                for t=1:ny;
                    if t==1;
                        tmat=(reshape(tfc(i,t,:,:),nx,ny)) * gx * hx(:,m);
                     else
                        tmat=[tmat ((reshape(tfc(i,t,:,:),nx,ny)) * gx * hx(:,m))];
                     end
                end
                q(i,j,k,m)= q(i,j,k,m) + (tmat'* hx(:,k))' * gx * hx(:,j);
 
                % Term 17
                tfc = reshape(fypxpy,n,ny,nx,ny);
                t=1;
                for t=1:ny;
                    if t==1;
                        tmat=(reshape(tfc(i,t,:,:),nx,ny)) * gx(:,m);
                     else
                        tmat=[tmat ((reshape(tfc(i,t,:,:),nx,ny)) * gx(:,m))];
                     end
                end
                q(i,j,k,m)= q(i,j,k,m) + (tmat'* hx(:,k))' * gx * hx(:,j);
                
                % Term 18
                tfc = reshape(fypxpxp,n,ny,nx,nx);
                t=1;
                for t=1:ny;
                    if t==1;
                        tmat=(reshape(tfc(i,t,:,:),nx,nx)) * hx(:,m);
                     else
                        tmat=[tmat ((reshape(tfc(i,t,:,:),nx,nx)) * hx(:,m))];
                     end
                end
                q(i,j,k,m)= q(i,j,k,m) + (tmat'* hx(:,k))' * gx * hx(:,j);
                
                % Term 19
                tfc = reshape(fypxpx,n,ny,nx,nx);
                t=1;
                for t=1:ny;
                    if t==1;
                         tmat=(reshape(tfc(i,t,:,m),nx,1));
                     else
                         tmat=[tmat ((reshape(tfc(i,t,:,m),nx,1)))];
                     end
                end
                q(i,j,k,m)= q(i,j,k,m) + ((tmat'* hx(:,k))' * gx * hx(:,j));
                
                % Term 20
                tfc = reshape(fypxp,n,ny,nx);
                q(i,j,k,m)= q(i,j,k,m) + (reshape(tfc(i,:,:),ny,nx) * hxx(:,k,m))' * gx * hx(:,j);
                
                % Term 21
                tfc = reshape(fypxp,n,ny,nx);
                t=1;
                for t=1:ny;
                    if t==1;
                         tmat=(reshape(gxx(t,:,:),nx,nx)) * hx(:,m);
                     else
                         tmat=[tmat ((reshape(gxx(t,:,:),nx,nx)) * hx(:,m))];
                     end
                end
                tmat = tmat' * hx(:,j);
                q(i,j,k,m)= q(i,j,k,m) + (reshape(tfc(i,:,:),ny,nx) * hx(:,k))' * tmat;
                
                % Term 22
                tfc = reshape(fypxp,n,ny,nx);
                q(i,j,k,m)= q(i,j,k,m) + (reshape(tfc(i,:,:),ny,nx) * hx(:,k))' * gx * hxx(:,j,m);

                % Term 23
                tfc = reshape(fypxyp,n,ny,nx,ny);
               q(i,j,k,m)= q(i,j,k,m) + (reshape(tfc(i,:,k,:),ny,ny) * gx * hx(:,m))' * gx * hx(:,j);

               % Term 24
               tfc = reshape(fypxy,n,ny,nx,ny);
               q(i,j,k,m)= q(i,j,k,m) + (reshape(tfc(i,:,k,:),ny,ny) * gx(:,m))' * gx * hx(:,j);
               
               % Term 25
               tfc = reshape(fypxxp,n,ny,nx,nx);
               q(i,j,k,m)= q(i,j,k,m) + (reshape(tfc(i,:,k,:),ny,nx) * hx(:,m))' * gx * hx(:,j);
 
               % Term 26
               tfc = reshape(fypxx,n,ny,nx,nx);
               q(i,j,k,m)= q(i,j,k,m) + tfc(i,:,k,m) * gx * hx(:,j);
               
               % Term 27
               tfc = reshape(fypx,n,ny,nx);
               t=1;
               for t=1:ny;
                    if t==1;
                         tmat=(reshape(gxx(t,:,:),nx,nx)) * hx(:,m);
                     else
                         tmat=[tmat ((reshape(gxx(t,:,:),nx,nx)) * hx(:,m))];
                     end
                end
                tmat = tmat' * hx(:,j);
                q(i,j,k,m)= q(i,j,k,m) + tfc(i,:,k) * tmat;

                % Term 28
                tfc = reshape(fypx,n,ny,nx);
                q(i,j,k,m)= q(i,j,k,m) + tfc(i,:,k) * gx * hxx(:,j,m);
                
                % Term 29
                tfc = reshape(fypyp,n,ny,ny);
                t=1;
                for t=1:ny;
                     if t==1;
                         tmat=(reshape(gxx(t,:,:),nx,nx)) * hx(:,k);
                     else
                         tmat=[tmat ((reshape(gxx(t,:,:),nx,nx)) * hx(:,k))];
                     end
                end
                tmat = tmat' * hx(:,j);
                q(i,j,k,m)= q(i,j,k,m) + (reshape(tfc(i,:,:),ny,ny) * gx * hx(:,m))' * (tmat + gx * hxx(:,j,k));
 
                % Term 30
                tfc = reshape(fypy,n,ny,ny);
                t=1;
                for t=1:ny;
                     if t==1;
                         tmat=(reshape(gxx(t,:,:),nx,nx)) * hx(:,k);
                     else
                         tmat=[tmat ((reshape(gxx(t,:,:),nx,nx)) * hx(:,k))];
                     end
                end
                tmat = tmat' * hx(:,j);
                q(i,j,k,m)= q(i,j,k,m) + (reshape(tfc(i,:,:),ny,ny) * gx(:,m))' * (tmat + gx * hxx(:,j,k));
 
                % Term 31
                tfc = reshape(fypxp,n,ny,nx);
                t=1;
                for t=1:ny;
                     if t==1;
                         tmat=(reshape(gxx(t,:,:),nx,nx)) * hx(:,k);
                     else
                         tmat=[tmat ((reshape(gxx(t,:,:),nx,nx)) * hx(:,k))];
                     end
                end
                tmat = tmat' * hx(:,j);
                q(i,j,k,m)= q(i,j,k,m) + (reshape(tfc(i,:,:),ny,nx) * hx(:,m))' * (tmat + gx * hxx(:,j,k));

                % Term 32
                tfc = reshape(fypx,n,ny,nx);
                t=1;
                for t=1:ny;
                     if t==1;
                         tmat=(reshape(gxx(t,:,:),nx,nx)) * hx(:,k);
                     else
                         tmat=[tmat ((reshape(gxx(t,:,:),nx,nx)) * hx(:,k))];
                     end
                end
                tmat = tmat' * hx(:,j);
                q(i,j,k,m)= q(i,j,k,m) + tfc(i,:,m) * (tmat + gx * hxx(:,j,k));

                % Term 33
                tfc = reshape(fyp,n,ny);
                t=1;
                for t=1:ny;
                     if t==1;
                         tmat=(reshape(gxx(t,:,:),nx,nx)) * hxx(:,k,m);
                     else
                         tmat=[tmat ((reshape(gxx(t,:,:),nx,nx)) * hxx(:,k,m))];
                     end
                end
                tmat = tmat' * hx(:,j);
                q(i,j,k,m)= q(i,j,k,m) + (reshape(tfc(i,:),ny,1))' * tmat;

                % Term 34
                tfc = reshape(fyp,n,ny);
                t=1;
                for t=1:ny;
                     if t==1;
                         tmat=(reshape(gxx(t,:,:),nx,nx)) * hx(:,k);
                     else
                         tmat=[tmat ((reshape(gxx(t,:,:),nx,nx)) * hx(:,k))];
                     end
                end
                tmat = tmat' * hxx(:,j,m);
                q(i,j,k,m)= q(i,j,k,m) + (reshape(tfc(i,:),ny,1))' * tmat;

                % Term 35
                tfc = reshape(fyp,n,ny);
                t=1;
                for t=1:ny;
                     if t==1;
                         tmat=(reshape(gxx(t,:,:),nx,nx)) * hx(:,m);
                     else
                         tmat=[tmat ((reshape(gxx(t,:,:),nx,nx)) * hx(:,m))];
                     end
                end
                tmat = tmat' * hxx(:,j,k);
                q(i,j,k,m)= q(i,j,k,m) + (reshape(tfc(i,:),ny,1))' * tmat;
                
                % Term 36
                tfc = reshape(fyypyp,n,ny,ny,ny);
                t=1;
                for t=1:ny;
                    if t==1;
                        tmat=(reshape(tfc(i,t,:,:),ny,ny)) * gx * hx(:,m);
                     else
                        tmat=[tmat ((reshape(tfc(i,t,:,:),ny,ny)) * gx * hx(:,m))];
                     end
                end
                q(i,j,k,m)= q(i,j,k,m) + (tmat' * gx * hx(:,k))' * gx(:,j);

                % Term 37
                tfc = reshape(fyypy,n,ny,ny,ny);
                t=1;
                for t=1:ny;
                    if t==1;
                         tmat=(reshape(tfc(i,t,:,:),ny,ny)) * gx(:,m);
                     else
                         tmat=[tmat ((reshape(tfc(i,t,:,:),ny,ny)) * gx(:,m))];
                     end
                end
                q(i,j,k,m)= q(i,j,k,m) + (tmat'* gx * hx(:,k))' * gx(:,j);

                % Term 38
                tfc = reshape(fyypxp,n,ny,ny,nx);
                t=1;
                for t=1:ny;
                    if t==1;
                         tmat=(reshape(tfc(i,t,:,:),ny,nx)) * hx(:,m);
                     else
                         tmat=[tmat ((reshape(tfc(i,t,:,:),ny,nx)) * hx(:,m))];
                     end
                end
                q(i,j,k,m)= q(i,j,k,m) + (tmat'* gx * hx(:,k))' * gx(:,j);

                % Term 39
                tfc = reshape(fyypx,n,ny,ny,nx);
                t=1;
                for t=1:ny;
                    if t==1;
                         tmat=(reshape(tfc(i,t,:,m),ny,1));
                     else
                         tmat=[tmat ((reshape(tfc(i,t,:,m),ny,1)))];
                     end
                end
                q(i,j,k,m)= q(i,j,k,m) + (tmat'* gx * hx(:,k))' * gx(:,j);

                % Term 40
                tfc = reshape(fyyp,n,ny,ny);
                t=1;
                for t=1:ny;
                     if t==1;
                         tmat=(reshape(gxx(t,:,:),nx,nx)) * hx(:,m);
                     else
                         tmat=[tmat ((reshape(gxx(t,:,:),nx,nx)) * hx(:,m))];
                     end
                end
                tmat = tmat' * hx(:,k);
                q(i,j,k,m)= q(i,j,k,m) + (reshape(tfc(i,:,:),ny,ny) * tmat)' * gx(:,j);

                % Term 41
                tfc = reshape(fyyp,n,ny,ny);
                q(i,j,k,m)= q(i,j,k,m) + (reshape(tfc(i,:,:),ny,ny) * gx * hxx(:,k,m))' * gx(:,j);

                % Term 42
                tfc = reshape(fyyp,n,ny,ny);
                q(i,j,k,m)= q(i,j,k,m) + (reshape(tfc(i,:,:),ny,ny) * gx * hx(:,k))' * gxx(:,j,m);

                % Term 43
                tfc = reshape(fyyyp,n,ny,ny,ny);
                t=1;
                for t=1:ny;
                    if t==1;
                        tmat=(reshape(tfc(i,t,:,:),ny,ny)) * gx * hx(:,m);
                     else
                        tmat=[tmat ((reshape(tfc(i,t,:,:),ny,ny)) * gx * hx(:,m))];
                     end
                end
                q(i,j,k,m)= q(i,j,k,m) + (tmat'* gx(:,k))' * gx(:,j);

                % Term 44
                tfc = reshape(fyyy,n,ny,ny,ny);
                t=1;
                for t=1:ny;
                    if t==1;
                         tmat=(reshape(tfc(i,t,:,:),ny,ny)) * gx(:,m);
                     else
                         tmat=[tmat ((reshape(tfc(i,t,:,:),ny,ny)) * gx(:,m))];
                     end
                end
                q(i,j,k,m)= q(i,j,k,m) + ((tmat'* gx(:,k))' * gx(:,j));

                % Term 45
                tfc = reshape(fyyxp,n,ny,ny,nx);
                t=1;
                for t=1:ny;
                    if t==1;
                         tmat=(reshape(tfc(i,t,:,:),ny,nx)) * hx(:,m);
                     else
                         tmat=[tmat ((reshape(tfc(i,t,:,:),ny,nx)) * hx(:,m))];
                     end
                end
                q(i,j,k,m)= q(i,j,k,m) + ((tmat'* gx(:,k))' * gx(:,j));

                % Term 46
                tfc = reshape(fyyx,n,ny,ny,nx);
                t=1;
                for t=1:ny;
                    if t==1;
                         tmat=(reshape(tfc(i,t,:,m),ny,1));
                     else
                         tmat=[tmat ((reshape(tfc(i,t,:,m),ny,1)))];
                     end
                end
                q(i,j,k,m)= q(i,j,k,m) + ((tmat'* gx(:,k))' * gx(:,j));

                % Term 47
                tfc = reshape(fyy,n,ny,ny);
                q(i,j,k,m)= q(i,j,k,m) + (reshape(tfc(i,:,:),ny,ny) * gxx(:,k,m))' * gx(:,j);

                % Term 48
                tfc = reshape(fyy,n,ny,ny);
                q(i,j,k,m)= q(i,j,k,m) + (reshape(tfc(i,:,:),ny,ny) * gx(:,k))' * gxx(:,j,m);

                % Term 49
                tfc = reshape(fyxpyp,n,ny,nx,ny);
                t=1;
                for t=1:ny;
                    if t==1;
                        tmat=(reshape(tfc(i,t,:,:),nx,ny)) * gx * hx(:,m);
                     else
                        tmat=[tmat ((reshape(tfc(i,t,:,:),nx,ny)) * gx * hx(:,m))];
                     end
                end
                q(i,j,k,m)= q(i,j,k,m) + (tmat'* hx(:,k))' * gx(:,j);

                % Term 50
                tfc = reshape(fyxpy,n,ny,nx,ny);
                t=1;
                for t=1:ny;
                    if t==1;
                         tmat=(reshape(tfc(i,t,:,:),nx,ny)) * gx(:,m);
                     else
                         tmat=[tmat ((reshape(tfc(i,t,:,:),nx,ny)) * gx(:,m))];
                     end
                end
                q(i,j,k,m)= q(i,j,k,m) + (tmat'* hx(:,k))' * gx(:,j);

                % Term 51
                tfc = reshape(fyxpxp,n,ny,nx,nx);
                t=1;
                for t=1:ny;
                    if t==1;
                         tmat=(reshape(tfc(i,t,:,:),nx,nx)) * hx(:,m);
                     else
                         tmat=[tmat ((reshape(tfc(i,t,:,:),nx,nx)) * hx(:,m))];
                     end
                end
                q(i,j,k,m)= q(i,j,k,m) + (tmat'* hx(:,k))' * gx(:,j);

                % Term 52
                tfc = reshape(fyxpx,n,ny,nx,nx);
                t=1;
                for t=1:ny;
                    if t==1;
                         tmat=(reshape(tfc(i,t,:,m),nx,1));
                     else
                         tmat=[tmat ((reshape(tfc(i,t,:,m),nx,1)))];
                     end
                end
                q(i,j,k,m)= q(i,j,k,m) + (tmat'* hx(:,k))' * gx(:,j);

                % Term 53
                tfc = reshape(fyxp,n,ny,nx);
                q(i,j,k,m)= q(i,j,k,m) + (reshape(tfc(i,:,:),ny,nx) * hxx(:,k,m))' * gx(:,j);
                
                % Term 54
                tfc = reshape(fyxp,n,ny,nx);
                q(i,j,k,m)= q(i,j,k,m) + (reshape(tfc(i,:,:),ny,nx) * hx(:,k))' * gxx(:,j,m);

                % Term 55
                tfc = reshape(fyxyp,n,ny,nx,ny);
                q(i,j,k,m)= q(i,j,k,m) + (reshape(tfc(i,:,k,:),ny,ny)* gx * hx(:,m))' * gx(:,j);
 
                % Term 56
                tfc = reshape(fyxy,n,ny,nx,ny);
                q(i,j,k,m)= q(i,j,k,m) + (reshape(tfc(i,:,k,:),ny,ny)* gx(:,m))' * gx(:,j);

                % Term 57
                tfc = reshape(fyxxp,n,ny,nx,nx);
                q(i,j,k,m)= q(i,j,k,m) + (reshape(tfc(i,:,k,:),ny,nx)* hx(:,m))' * gx(:,j);
 
                % Term 58
                tfc = reshape(fyxx,n,ny,nx,nx);
                q(i,j,k,m)= q(i,j,k,m) + (reshape(tfc(i,:,k,m),ny,1))' * gx(:,j);

                % Term 59
                tfc = reshape(fyx,n,ny,nx);
                q(i,j,k,m)= q(i,j,k,m) + (reshape(tfc(i,:,k),ny,1))' * gxx(:,j,m);

                % Term 60
                tfc = reshape(fyyp,n,ny,ny);
                q(i,j,k,m)= q(i,j,k,m) + (reshape(tfc(i,:,:),ny,ny) * gx * hx(:,m))' * gxx(:,j,k);
 
                % Term 61
                tfc = reshape(fyy,n,ny,ny);
                q(i,j,k,m)= q(i,j,k,m) + (reshape(tfc(i,:,:),ny,ny) * gx(:,m))' * gxx(:,j,k);
 
                % Term 62
                tfc = reshape(fyxp,n,ny,nx);
                q(i,j,k,m)= q(i,j,k,m) + (reshape(tfc(i,:,:),ny,nx) * hx(:,m))' * gxx(:,j,k);

                % Term 63
                tfc = reshape(fyx,n,ny,nx);
                q(i,j,k,m)= q(i,j,k,m) + (reshape(tfc(i,:,m),ny,1))' * gxx(:,j,k);
 
                % Term 64
                tfc = reshape(fxpypyp,n,nx,ny,ny);
                t=1;
                for t=1:nx;
                    if t==1;
                        tmat=(reshape(tfc(i,t,:,:),ny,ny)) * gx * hx(:,m);
                     else
                        tmat=[tmat ((reshape(tfc(i,t,:,:),ny,ny)) * gx * hx(:,m))];
                     end
                end
                q(i,j,k,m)= q(i,j,k,m) + (tmat'* gx * hx(:,k))' * hx(:,j);
 
                % Term 65
                tfc = reshape(fxpypy,n,nx,ny,ny);
                t=1;
                for t=1:nx;
                    if t==1;
                         tmat=(reshape(tfc(i,t,:,:),ny,ny)) * gx(:,m);
                     else
                         tmat=[tmat ((reshape(tfc(i,t,:,:),ny,ny)) * gx(:,m))];
                     end
                end
                q(i,j,k,m)= q(i,j,k,m) + ((tmat'* gx * hx(:,k))' * hx(:,j));

                % Term 66
                tfc = reshape(fxpypxp,n,nx,ny,nx);
                t=1;
                for t=1:nx;
                    if t==1;
                         tmat=(reshape(tfc(i,t,:,:),ny,nx)) * hx(:,m);
                     else
                         tmat=[tmat ((reshape(tfc(i,t,:,:),ny,nx)) * hx(:,m))];
                     end
                end
                q(i,j,k,m)= q(i,j,k,m) + ((tmat'* gx * hx(:,k))' * hx(:,j));
 
                % Term 67
                tfc = reshape(fxpypx,n,nx,ny,nx);
                t=1;
                for t=1:nx;
                    if t==1;
                         tmat=(reshape(tfc(i,t,:,m),ny,1));
                     else
                         tmat=[tmat ((reshape(tfc(i,t,:,m),ny,1)))];
                     end
                end
                q(i,j,k,m)= q(i,j,k,m) + ((tmat'* gx * hx(:,k))' * hx(:,j));

                % Term 68
                tfc = reshape(fxpyp,n,nx,ny);
                t=1;
                for t=1:ny;
                    if t==1;
                         tmat=(reshape(gxx(t,:,:),nx,nx)) * hx(:,m);
                     else
                         tmat=[tmat ((reshape(gxx(t,:,:),nx,nx)) * hx(:,m))];
                     end
                end
                tmat = tmat' * hx(:,k);
                q(i,j,k,m)= q(i,j,k,m) + (reshape(tfc(i,:,:),nx,ny) * tmat)' * hx(:,j);

                % Term 69
                tfc = reshape(fxpyp,n,nx,ny);
                q(i,j,k,m)= q(i,j,k,m) + (reshape(tfc(i,:,:),nx,ny) * gx * hxx(:,k,m))' * hx(:,j);

                % Term 70
                tfc = reshape(fxpyp,n,nx,ny);
                q(i,j,k,m)= q(i,j,k,m) + (reshape(tfc(i,:,:),nx,ny) * gx * hx(:,k))' * hxx(:,j,m);

                % Term 71
                tfc = reshape(fxpyyp,n,nx,ny,ny);
                t=1;
                for t=1:nx;
                    if t==1;
                        tmat=(reshape(tfc(i,t,:,:),ny,ny)) * gx * hx(:,m);
                     else
                        tmat=[tmat ((reshape(tfc(i,t,:,:),ny,ny)) * gx * hx(:,m))];
                     end
                end
                q(i,j,k,m)= q(i,j,k,m) + (tmat'* gx(:,k))' * hx(:,j);
                
                % Term 72
                tfc = reshape(fxpyy,n,nx,ny,ny);
                t=1;
                for t=1:nx;
                    if t==1;
                         tmat=(reshape(tfc(i,t,:,:),ny,ny)) * gx(:,m);
                     else
                         tmat=[tmat ((reshape(tfc(i,t,:,:),ny,ny)) * gx(:,m))];
                     end
                end
                q(i,j,k,m)= q(i,j,k,m) + ((tmat'* gx(:,k))' * hx(:,j));

                % Term 73
                tfc = reshape(fxpyxp,n,nx,ny,nx);
                t=1;
                for t=1:nx;
                    if t==1;
                         tmat=(reshape(tfc(i,t,:,:),ny,nx)) * hx(:,m);
                     else
                         tmat=[tmat ((reshape(tfc(i,t,:,:),ny,nx)) * hx(:,m))];
                     end
                end
                q(i,j,k,m)= q(i,j,k,m) + ((tmat'* gx(:,k))' * hx(:,j));

                % Term 74
                tfc = reshape(fxpyx,n,nx,ny,nx);
                t=1;
                for t=1:nx;
                    if t==1;
                         tmat=(reshape(tfc(i,t,:,m),ny,1));
                     else
                         tmat=[tmat ((reshape(tfc(i,t,:,m),ny,1)))];
                     end
                end
               q(i,j,k,m)= q(i,j,k,m) + ((tmat'* gx(:,k))' * hx(:,j));
               
               % Term 75
               tfc = reshape(fxpy,n,nx,ny);        
               q(i,j,k,m)= q(i,j,k,m) + (reshape(tfc(i,:,:),nx,ny) * gxx(:,k,m))' * hx(:,j);
 
               % Term 76
               tfc = reshape(fxpy,n,nx,ny);
                q(i,j,k,m)= q(i,j,k,m) + (reshape(tfc(i,:,:),nx,ny) * gx(:,k))' * hxx(:,j,m);

                % Term 77
                tfc = reshape(fxpxpyp,n,nx,nx,ny);
                t=1;
                for t=1:nx;
                    if t==1;
                        tmat=(reshape(tfc(i,t,:,:),nx,ny)) * gx * hx(:,m);
                     else
                        tmat=[tmat ((reshape(tfc(i,t,:,:),nx,ny)) * gx * hx(:,m))];
                     end
                end
                q(i,j,k,m)= q(i,j,k,m) + (tmat'* hx(:,k))' * hx(:,j);

                % Term 78
                tfc = reshape(fxpxpy,n,nx,nx,ny);
                t=1;
                for t=1:nx;
                    if t==1;
                         tmat=(reshape(tfc(i,t,:,:),nx,ny)) * gx(:,m);
                     else
                         tmat=[tmat ((reshape(tfc(i,t,:,:),nx,ny)) * gx(:,m))];
                     end
                end
                q(i,j,k,m)= q(i,j,k,m) + ((tmat'* hx(:,k))' * hx(:,j));
                
                % Term 79
                tfc = reshape(fxpxpxp,n,nx,nx,nx);
                t=1;
                for t=1:nx;
                    if t==1;
                         tmat=(reshape(tfc(i,t,:,:),nx,nx)) * hx(:,m);
                     else
                         tmat=[tmat ((reshape(tfc(i,t,:,:),nx,nx)) * hx(:,m))];
                     end
                end
                q(i,j,k,m)= q(i,j,k,m) + ((tmat'* hx(:,k))' * hx(:,j));

                % Term 80
                tfc = reshape(fxpxpx,n,nx,nx,nx);
                t=1;
                for t=1:nx;
                    if t==1;
                         tmat=(reshape(tfc(i,t,:,m),nx,1));
                     else
                         tmat=[tmat ((reshape(tfc(i,t,:,m),nx,1)))];
                     end
                end
                q(i,j,k,m)= q(i,j,k,m) + ((tmat'* hx(:,k))' * hx(:,j));

                % Term 81
                tfc = reshape(fxpxp,n,nx,nx);
                q(i,j,k,m)= q(i,j,k,m) + (reshape(tfc(i,:,:),nx,nx) * hxx(:,k,m))' * hx(:,j);

                % Term 82
                tfc = reshape(fxpxp,n,nx,nx);
                q(i,j,k,m)= q(i,j,k,m) + (reshape(tfc(i,:,:),nx,nx) * hx(:,k))' * hxx(:,j,m);

                % Term 83
                tfc = reshape(fxpxyp,n,nx,nx,ny);
                q(i,j,k,m)= q(i,j,k,m) + (reshape(tfc(i,:,k,:),nx,ny)* gx * hx(:,m))' * hx(:,j);

                % Term 84
                tfc = reshape(fxpxy,n,nx,nx,ny);
                q(i,j,k,m)= q(i,j,k,m) + (reshape(tfc(i,:,k,:),nx,ny)* gx(:,m))' * hx(:,j);

                % Term 85
                tfc = reshape(fxpxxp,n,nx,nx,nx);
                q(i,j,k,m)= q(i,j,k,m) + (reshape(tfc(i,:,k,:),nx,nx)* hx(:,m))' * hx(:,j);

                % Term 86
                tfc = reshape(fxpxx,n,nx,nx,nx);
                q(i,j,k,m)= q(i,j,k,m) + (reshape(tfc(i,:,k,m),nx,1))' * hx(:,j);
 
                % Term 87
                tfc = reshape(fxpx,n,nx,nx);
                q(i,j,k,m)= q(i,j,k,m) + (reshape(tfc(i,:,k),nx,1))' * hxx(:,j,m);

                % Term 88
                tfc = reshape(fxpyp,n,nx,ny);
                q(i,j,k,m)= q(i,j,k,m) + (reshape(tfc(i,:,:),nx,ny) * gx * hx(:,m))' * hxx(:,j,k);

                % Term 89
                tfc = reshape(fxpy,n,nx,ny);
                q(i,j,k,m)= q(i,j,k,m) + (reshape(tfc(i,:,:),nx,ny) * gx(:,m))' * hxx(:,j,k);
 
                % Term 90
                tfc = reshape(fxpxp,n,nx,nx);
                q(i,j,k,m)= q(i,j,k,m) + (reshape(tfc(i,:,:),nx,nx) * hx(:,m))' * hxx(:,j,k);

                % Term 91
                tfc = reshape(fxpx,n,nx,nx);
                q(i,j,k,m)= q(i,j,k,m) + (reshape(tfc(i,:,m),nx,1))' * hxx(:,j,k);
                
                % Term 92
                tfc = reshape(fxypyp,n,nx,ny,ny);
                q(i,j,k,m)= q(i,j,k,m) + (reshape(tfc(i,j,:,:),ny,ny)* gx * hx(:,m))' * gx * hx(:,k);

                % Term 93
                tfc = reshape(fxypy,n,nx,ny,ny);
                q(i,j,k,m)= q(i,j,k,m) + (reshape(tfc(i,j,:,:),ny,ny)* gx(:,m))' * gx * hx(:,k);

                % Term 94
                tfc = reshape(fxypxp,n,nx,ny,nx);
                q(i,j,k,m)= q(i,j,k,m) + (reshape(tfc(i,j,:,:),ny,nx)* hx(:,m))' * gx * hx(:,k);

                % Term 95
                tfc = reshape(fxypx,n,nx,ny,nx);
                q(i,j,k,m)= q(i,j,k,m) + (reshape(tfc(i,j,:,m),ny,1))' * gx * hx(:,k);

                % Term 96
                tfc = reshape(fxyp,n,nx,ny);
                t=1;
                for t=1:ny;
                    if t==1;
                         tmat=(reshape(gxx(t,:,:),nx,nx)) * hx(:,m);
                     else
                         tmat=[tmat ((reshape(gxx(t,:,:),nx,nx)) * hx(:,m))];
                     end
                end
                tmat = tmat' * hx(:,k);
                q(i,j,k,m)= q(i,j,k,m) + (reshape(tfc(i,j,:),ny,1))' * tmat;

                % Term 97
                tfc = reshape(fxyp,n,nx,ny);
                q(i,j,k,m)= q(i,j,k,m) + (reshape(tfc(i,j,:),ny,1))' * gx * hxx(:,k,m);
                
                % Term 98
                tfc = reshape(fxyyp,n,nx,ny,ny);
                q(i,j,k,m)= q(i,j,k,m) + (reshape(tfc(i,j,:,:),ny,ny)* gx * hx(:,m))' * gx(:,k);
                
                % Term 99
                tfc = reshape(fxyy,n,nx,ny,ny);
                q(i,j,k,m)= q(i,j,k,m) + (reshape(tfc(i,j,:,:),ny,ny)* gx(:,m))' * gx(:,k);
                
                % Term 100
                tfc = reshape(fxyxp,n,nx,ny,nx);
                q(i,j,k,m)= q(i,j,k,m) + (reshape(tfc(i,j,:,:),ny,nx)* hx(:,m))' * gx(:,k);
                
                % Term 101
                tfc = reshape(fxyx,n,nx,ny,nx);
                q(i,j,k,m)= q(i,j,k,m) + (reshape(tfc(i,j,:,m),ny,1))' * gx(:,k);
                
                % Term 102
                tfc = reshape(fxy,n,nx,ny);
                q(i,j,k,m)= q(i,j,k,m) + (reshape(tfc(i,j,:),ny,1))' * gxx(:,k,m);
                
                % Term 103
                tfc = reshape(fxxpyp,n,nx,nx,ny);
                q(i,j,k,m)= q(i,j,k,m) + (reshape(tfc(i,j,:,:),nx,ny)* gx * hx(:,m))' * hx(:,k);

                % Term 104
                tfc = reshape(fxxpy,n,nx,nx,ny);
                q(i,j,k,m)= q(i,j,k,m) + (reshape(tfc(i,j,:,:),nx,ny)* gx(:,m))' * hx(:,k);
                
                % Term 105
                tfc = reshape(fxxpxp,n,nx,nx,nx);
                q(i,j,k,m)= q(i,j,k,m) + (reshape(tfc(i,j,:,:),nx,nx)* hx(:,m))' * hx(:,k);

                % Term 106
                tfc = reshape(fxxpx,n,nx,nx,nx);
                q(i,j,k,m)= q(i,j,k,m) + (reshape(tfc(i,j,:,m),nx,1))' * hx(:,k);
                
                % Term 107
                tfc = reshape(fxxp,n,nx,nx);
                q(i,j,k,m)= q(i,j,k,m) + (reshape(tfc(i,j,:),nx,1))' * hxx(:,k,m);
                
                % Term 108
                tfc = reshape(fxxyp,n,nx,nx,ny);
                q(i,j,k,m)= q(i,j,k,m) + (reshape(tfc(i,j,k,:),ny,1))' * gx * hx(:,m);
                
                % Term 109
                tfc = reshape(fxxy,n,nx,nx,ny);
               q(i,j,k,m)= q(i,j,k,m) + (reshape(tfc(i,j,k,:),ny,1))' * gx(:,m);
               
               % Term 110
               tfc = reshape(fxxxp,n,nx,nx,nx);
               q(i,j,k,m)= q(i,j,k,m) + (reshape(tfc(i,j,k,:),nx,1))' * hx(:,m);
               
               % Term 111
               tfc = reshape(fxxx,n,nx,nx,nx);
               q(i,j,k,m)= q(i,j,k,m) + tfc(i,j,k,m);
                
               % Exploit symmetry to reduce computational burden
                q(i,k,j,m)= q(i,j,k,m);
            end
        end
    end
end

% Reshape constants
q = permute(q,[4 3 2 1]);
q = reshape(q,n*nx*nx*nx,1);


% COMPUTE COEFFICIENTS OF GXXX AND HXXX
ngxxx = nx^3*ny; % elements of gxxx
nhxxx = nx^4; % elements of hxxx
sg = [ny nx nx nx]; %size of gxxx
sh = [nx nx nx nx]; %size of hxxx

Q = zeros(n*nx*nx*nx,ngxxx+nhxxx);

gxxx=zeros(sg);
hxxx=zeros(sh);
GXXX=zeros(sg);
HXXX=zeros(sh);

t = 0;
for i=1:n
    for j=1:nx
        for k=1:nx
            for m=1:nx;
                t = t+1;
                GXXX(:) = kron(ones(nx^3,1),fyp(i,:)');
                                
                pGXXX = permute(GXXX,[2 4 3 1]);
                pGXXX(:) = pGXXX(:) .* kron(ones(nx*nx*ny,1),hx(:,j));
                GXXX=ipermute(pGXXX,[2 4 3 1]);
                
                pGXXX = permute(GXXX,[3 4 1 2]);
                pGXXX(:) = pGXXX(:) .* kron(ones(nx*nx*ny,1),hx(:,k));
                GXXX=ipermute(pGXXX,[3 4 1 2]);

                pGXXX = permute(GXXX,[4 1 2 3]);
                pGXXX(:) = pGXXX(:) .* kron(ones(nx*nx*ny,1),hx(:,m));
                GXXX=ipermute(pGXXX,[4 1 2 3]);
                
                Q(t,1:ngxxx)=GXXX(:)';
                GXXX=0*GXXX;

                HXXX(:,j,k,m) = (fyp(i,:) * gx)';
                Q(t,ngxxx+1:end)=HXXX(:)';
                HXXX = 0*HXXX;

                GXXX(:,j,k,m)=fy(i,:)';
                Q(t,1:ngxxx) = Q(t,1:ngxxx) + GXXX(:)';
                GXXX = 0*GXXX;

                HXXX(:,j,k,m)=fxp(i,:)';
                Q(t,ngxxx+1:end) = Q(t,ngxxx+1:end) + HXXX(:)';
                HXXX = 0*HXXX;
            end
        end
    end
end


% SOLVE FOR THIRD-ORDER COEFFICIENTS
cc = -Q\q;
gxxx(:) = cc(1:ngxxx);
hxxx(:) = cc(ngxxx+1:end);
