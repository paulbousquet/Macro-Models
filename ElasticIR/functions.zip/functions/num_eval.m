% NUM_EVAL.M
% This program evaluates the analytical derivatives of f numerically. 
% The parameters and steady state values of the arguments of the function f are assumed to be in the workspace. 
% Also, the order of approximation must be in the workspace.

%(c) Francisco Ruge-Murcia (July 2006)
% In September 2010, changes were made to the companion programs GSSS_HSSS.M and % GXSS_HXSS.M

global approx
global fx fxp fy fyp fypyp fypy fypxp fypx fyyp fyy fyxp fyx fxpyp fxpy fxpxp fxpx fxyp fxy fxxp fxx
global fypypyp fypypy fypypxp fypypx fypyyp fypyy fypyxp fypyx fypxpyp fypxpy fypxpxp fypxpx fypxyp fypxy fypxxp fypxx
global fyypyp fyypy fyypxp fyypx fyyyp fyyy fyyxp fyyx fyxpyp fyxpy fyxpxp fyxpx fyxyp fyxy fyxxp fyxx
global fxpypyp fxpypy fxpypxp fxpypx fxpyyp fxpyy fxpyxp fxpyx fxpxpyp fxpxpy fxpxpxp fxpxpx fxpxyp fxpxy fxpxxp fxpxx
global fxypyp fxypy fxypxp fxypx fxyyp fxyy fxyxp fxyx fxxpyp fxxpy fxxpxp fxxpx fxxyp fxxy fxxxp fxxx f

% First-order derivatives
nfx = zeros(size(fx));
nfx(:) = eval(fx(:));

nfxp = zeros(size(fxp));
nfxp(:)= eval(fxp(:));

nfy = zeros(size(fy));
nfy(:) = eval(fy(:));

nfyp = zeros(size(fyp));
nfyp(:)= eval(fyp(:));

nf = zeros(size(f));
nf(:)=eval(f(:));

% Second-order derivatives
if approx > 1
    nfypyp=zeros(size(fypyp));
    nfypyp(:)=eval(fypyp(:));

    nfypy=zeros(size(fypy));
    nfypy(:)=eval(fypy(:));

    nfypxp=zeros(size(fypxp));
    nfypxp(:)=eval(fypxp(:));

    nfypx=zeros(size(fypx));
    nfypx(:)=eval(fypx(:));

    nfyyp=zeros(size(fyyp));
    nfyyp(:)=eval(fyyp(:));

    nfyy=zeros(size(fyy));
    nfyy(:)=eval(fyy(:));

    nfyxp=zeros(size(fyxp));
    nfyxp(:)=eval(fyxp(:));

    nfyx=zeros(size(fyx));
    nfyx(:)=eval(fyx(:));

    nfxpyp=zeros(size(fxpyp));
    nfxpyp(:)=eval(fxpyp(:));

    nfxpy=zeros(size(fxpy));
    nfxpy(:)=eval(fxpy(:));

    nfxpxp=zeros(size(fxpxp));
    nfxpxp(:)=eval(fxpxp(:));

    nfxpx=zeros(size(fxpx));
    nfxpx(:)=eval(fxpx(:));

    nfxyp=zeros(size(fxyp));
    nfxyp(:)=eval(fxyp(:));

    nfxy=zeros(size(fxy));
    nfxy(:)=eval(fxy(:));

    nfxxp=zeros(size(fxxp));
    nfxxp(:)=eval(fxxp(:));

    nfxx=zeros(size(fxx));
    nfxx(:)=eval(fxx(:));
    
else
    nfypyp=0; 
    nfypy=0; 
    nfypxp=0; 
    nfypx=0; 
    nfyyp=0; 
    nfyy=0; 
    nfyxp=0; 
    nfyx=0; 
    nfxpyp=0; 
    nfxpy=0; 
    nfxpxp=0; 
    nfxpx=0; 
    nfxyp=0; 
    nfxy=0; 
    nfxxp=0; 
    nfxx=0;
end 

% Third-order derivative
if approx>2
    nfypypyp = zeros(size(fypypyp)); 
    nfypypy =  zeros(size(fypypy));   
    nfypypxp = zeros(size(fypypxp));
    nfypypx =  zeros(size(fypypx));
    nfypypyp(:) = eval(fypypyp(:)); 
    nfypypy(:) = eval(fypypy(:));   
    nfypypxp(:) = eval(fypypxp(:));
    nfypypx(:) = eval(fypypx(:));
     
    nfypyyp = zeros(size(fypyyp));
    nfypyy  = zeros(size(fypyy));
    nfypyxp = zeros(size(fypyxp));
    nfypyx  = zeros(size(fypyx));
    nfypyyp(:) = eval(fypyyp(:));
    nfypyy (:) = eval(fypyy(:));
    nfypyxp(:) = eval(fypyxp(:));
    nfypyx (:) = eval(fypyx(:));
    
    nfypxpyp = zeros(size(fypxpyp));
    nfypxpy  = zeros(size(fypxpy));
    nfypxpxp = zeros(size(fypxpxp));
    nfypxpx  = zeros(size(fypxpx));
    nfypxpyp(:) = eval(fypxpyp(:));
    nfypxpy (:) = eval(fypxpy(:));
    nfypxpxp(:) = eval(fypxpxp(:));
    nfypxpx (:) = eval(fypxpx(:));
    
    nfypxyp = zeros(size(fypxyp));
    nfypxy  = zeros(size(fypxy));
    nfypxxp = zeros(size(fypxxp));
    nfypxx  = zeros(size(fypxx));
    nfypxyp(:) = eval(fypxyp(:));
    nfypxy (:) = eval(fypxy(:));
    nfypxxp(:) = eval(fypxxp(:));
    nfypxx (:) = eval(fypxx(:));
    
    nfyypyp = zeros(size(fyypyp));
    nfyypy  = zeros(size(fyypy));
    nfyypxp = zeros(size(fyypxp));
    nfyypx  = zeros(size(fyypx));
    nfyypyp(:) = eval(fyypyp(:));
    nfyypy (:) = eval(fyypy(:));
    nfyypxp(:) = eval(fyypxp(:));
    nfyypx (:) = eval(fyypx(:));
    
    nfyyyp = zeros(size(fyyyp));
    nfyyy  = zeros(size(fyyy));
    nfyyxp = zeros(size(fyyxp));
    nfyyx  = zeros(size(fyyx));
    nfyyyp(:) = eval(fyyyp(:));
    nfyyy (:) = eval(fyyy(:));
    nfyyxp(:) = eval(fyyxp(:));
    nfyyx (:) = eval(fyyx(:));
    
    nfyxpyp = zeros(size(fyxpyp));
    nfyxpy  = zeros(size(fyxpy));
    nfyxpxp = zeros(size(fyxpxp));
    nfyxpx  = zeros(size(fyxpx));
    nfyxpyp(:) = eval(fyxpyp(:));
    nfyxpy (:) = eval(fyxpy(:));
    nfyxpxp(:) = eval(fyxpxp(:));
    nfyxpx (:) = eval(fyxpx(:));
    
    nfyxyp = zeros(size(fyxyp));
    nfyxy  = zeros(size(fyxy));
    nfyxxp = zeros(size(fyxxp));
    nfyxx  = zeros(size(fyxx));
    nfyxyp(:) = eval(fyxyp(:));
    nfyxy (:) = eval(fyxy(:));
    nfyxxp(:) = eval(fyxxp(:));
    nfyxx (:) = eval(fyxx(:));
    
    nfxpypyp = zeros(size(fxpypyp));
    nfxpypy  = zeros(size(fxpypy));
    nfxpypxp = zeros(size(fxpypxp));
    nfxpypx  = zeros(size(fxpypx));
    nfxpypyp(:) = eval(fxpypyp(:));
    nfxpypy (:) = eval(fxpypy(:));
    nfxpypxp(:) = eval(fxpypxp(:));
    nfxpypx (:) = eval(fxpypx(:));
      
    nfxpyyp = zeros(size(fxpyyp));
    nfxpyy  = zeros(size(fxpyy));
    nfxpyxp = zeros(size(fxpyxp));
    nfxpyx  = zeros(size(fxpyx));
    nfxpyyp(:) = eval(fxpyyp(:));
    nfxpyy (:) = eval(fxpyy(:));
    nfxpyxp(:) = eval(fxpyxp(:));
    nfxpyx (:) = eval(fxpyx(:));
    
    nfxpxpyp = zeros(size(fxpxpyp));
    nfxpxpy  = zeros(size(fxpxpy));
    nfxpxpxp = zeros(size(fxpxpxp));
    nfxpxpx  = zeros(size(fxpxpx));
    nfxpxpyp(:) = eval(fxpxpyp(:));
    nfxpxpy (:) = eval(fxpxpy(:));
    nfxpxpxp(:) = eval(fxpxpxp(:));
    nfxpxpx (:) = eval(fxpxpx(:));
     
    nfxpxyp = zeros(size(fxpxyp));
    nfxpxy  = zeros(size(fxpxy));
    nfxpxxp = zeros(size(fxpxxp));
    nfxpxx  = zeros(size(fxpxx));
    nfxpxyp(:) = eval(fxpxyp(:));
    nfxpxy (:) = eval(fxpxy(:));
    nfxpxxp(:) = eval(fxpxxp(:));
    nfxpxx (:) = eval(fxpxx(:));
   
    nfxypyp = zeros(size(fxypyp));
    nfxypy  = zeros(size(fxypy));
    nfxypxp = zeros(size(fxypxp));
    nfxypx  = zeros(size(fxypx));
    nfxypyp(:) = eval(fxypyp(:));
    nfxypy (:) = eval(fxypy(:));
    nfxypxp(:) = eval(fxypxp(:));
    nfxypx (:) = eval(fxypx(:));
    
    nfxyyp = zeros(size(fxyyp));
    nfxyy  = zeros(size(fxyy));
    nfxyxp = zeros(size(fxyxp));
    nfxyx  = zeros(size(fxyx));
    nfxyyp(:) = eval(fxyyp(:));
    nfxyy (:) = eval(fxyy(:));
    nfxyxp(:) = eval(fxyxp(:));
    nfxyx (:) = eval(fxyx(:));
    
    nfxxpyp = zeros(size(fxxpyp));
    nfxxpy  = zeros(size(fxxpy));
    nfxxpxp = zeros(size(fxxpxp));
    nfxxpx  = zeros(size(fxxpx));
    nfxxpyp(:) = eval(fxxpyp(:));
    nfxxpy (:) = eval(fxxpy(:));
    nfxxpxp(:) = eval(fxxpxp(:));
    nfxxpx (:) = eval(fxxpx(:));
     
    nfxxyp = zeros(size(fxxyp));
    nfxxy  = zeros(size(fxxy));
    nfxxxp = zeros(size(fxxxp));
    nfxxx  = zeros(size(fxxx));
    nfxxyp(:) = eval(fxxyp(:));
    nfxxy (:) = eval(fxxy(:));
    nfxxxp(:) = eval(fxxxp(:));
    nfxxx (:) = eval(fxxx(:));
else
    nfypypyp=0;
    nfypypy=0;
    nfypypxp=0;
    nfypypx=0;
    nfypyyp=0;
    nfypyy=0;
    nfypyxp=0;
    nfypyx=0;
    nfypxpyp=0;
    nfypxpy=0;
    nfypxpxp=0;
    nfypxpx=0;
    nfypxyp=0;
    nfypxy=0;
    nfypxxp=0;
    nfypxx=0;
    nfyypyp=0;
    nfyypy=0;
    nfyypxp=0;
    nfyypx=0;
    nfyyyp=0;
    nfyyy=0;
    nfyyxp=0;
    nfyyx=0;
    nfyxpyp=0;
    nfyxpy=0;
    nfyxpxp=0;
    nfyxpx=0;
    nfyxyp=0;
    nfyxy=0;
    nfyxxp=0;
    nfyxx=0;
    nfxpypyp=0;
    nfxpypy=0;
    nfxpypxp=0;
    nfxpypx=0;
    nfxpyyp=0;
    nfxpyy=0;
    nfxpyxp=0;
    nfxpyx=0;
    nfxpxpyp=0;
    nfxpxpy=0;
    nfxpxpxp=0;
    nfxpxpx=0;
    nfxpxyp=0;
    nfxpxy=0;
    nfxpxxp=0;
    nfxpxx=0;
    nfxypyp=0;
    nfxypy=0;
    nfxypxp=0;
    nfxypx=0;
    nfxyyp=0;
    nfxyy=0;
    nfxyxp=0;
    nfxyx=0;
    nfxxpyp=0;
    nfxxpy=0;
    nfxxpxp=0;
    nfxxpx=0;
    nfxxyp=0;
    nfxxy=0;
    nfxxxp=0;
    nfxxx=0;
end