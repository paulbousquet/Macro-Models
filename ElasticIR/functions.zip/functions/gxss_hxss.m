% GXSS_HXSS.M
% This program finds the 2-dimensional arrays gxss and hxss necessary to compute the 3rd order approximation to the decision rules of a DSGE model of the form 
% E_tf(yp,y,xp,x)=0, with solution xp=h(x,sigma) + sigma * eta * ep and y=g(x,sigma). 
% INPUTS: First, second and third order derivatives of f and first- and second-order approximations to the functions g and h
% OUTPUTS: Third-order derivatives of the functions g and h with respect to x, evaluated at (x,sigma)=(xbar,0), where xbar=h(xbar,0). 

%(c) Francisco Ruge-Murcia (July 2006)
% In September 2010, the way Term 15 is computed was changed and terms involving hss and gss (e.g, Terms 3 and 6) were taken from the inner loop.
% These changes generalize the code to models with more than one structural shock.


function [gxss,hxss] = gxss_hxss(fx,fxp,fy,fyp,fypyp,fypy,fypxp,fypx,fyyp,fyy,fyxp,fyx,fxpyp,fxpy,fxpxp,fxpx,fxyp,fxy,fxxp,fxx,...
    fypypyp,fypypy,fypypxp,fypypx,fypyyp,fypyy,fypyxp,fypyx,fypxpyp,fypxpy,fypxpxp,fypxpx,fypxyp,fypxy,fypxxp,fypxx,...
    fyypyp,fyypy,fyypxp,fyypx,fyyyp,fyyy,fyyxp,fyyx,fyxpyp,fyxpy,fyxpxp,fyxpx,fyxyp,fyxy,fyxxp,fyxx,...
    fxpypyp,fxpypy,fxpypxp,fxpypx,fxpyyp,fxpyy,fxpyxp,fxpyx,fxpxpyp,fxpxpy,fxpxpxp,fxpxpx,fxpxyp,fxpxy,fxpxxp,fxpxx,...
    fxypyp,fxypy,fxypxp,fxypx,fxyyp,fxyy,fxyxp,fxyx,fxxpyp,fxxpy,fxxpxp,fxxpx,fxxyp,fxxy,fxxxp,fxxx,...
    hx,gx,hxx,gxx,gxxx,gss,hss,eta)
                                

nx = size(hx,1); % rows of hx, hxx and hxx
ny = size(gx,1); % rows of gx, gxx and gxx
n = nx + ny; % length of f
ne = size(eta,2); %number of exogenous shocks (columns of eta)


% COMPUTE CONSTANT TERMS
q = zeros(n,nx); % array with constant terms

for i=1:n
      for j=1:nx
               % Term 3
               tfc = reshape(fypyp,n,ny,ny);
               q(i,j)= q(i,j) + (reshape(tfc(i,:,:),ny,ny) * gx * hss)' * gx * hx(:,j);
    
               % Term 6
               tfc = reshape(fypyp,n,ny,ny);
               q(i,j)= q(i,j) + (reshape(tfc(i,:,:),ny,ny) * gss)' * gx * hx(:,j);

               % Term 7
               tfc = reshape(fypy,n,ny,ny);
               q(i,j)= q(i,j) + (reshape(tfc(i,:,:),ny,ny) * gss)' * gx * hx(:,j);
                
               % Term 8
               tfc = reshape(fypxp,n,ny,nx);
               q(i,j)= q(i,j) + (reshape(tfc(i,:,:),ny,nx) * hss)' * gx * hx(:,j);
                
               % Term 14
                tfc = reshape(fyp,n,ny);
                t=1;
                for t=1:ny;
                    if t==1;
                         tmat=(reshape(gxx(t,:,:),nx,nx)) * hss;
                     else
                         tmat=[tmat ((reshape(gxx(t,:,:),nx,nx)) * hss)];
                     end
                end
                tmat = tmat' * hx(:,j);
                q(i,j)= q(i,j) + (reshape(tfc(i,:),ny,1))' * tmat;
                
                % Term 18
                tfc = reshape(fyyp,n,ny,ny);
                q(i,j)= q(i,j) + ((reshape(tfc(i,:,:),ny,ny) * gx * hss)' * gx(:,j));
                
                % Term 20
                tfc = reshape(fyyp,n,ny,ny);
                q(i,j)= q(i,j) + (reshape(tfc(i,:,:),ny,ny) * gss)' * gx(:,j);
 
                % Term 21
                tfc = reshape(fyy,n,ny,ny);
                q(i,j)= q(i,j) + (reshape(tfc(i,:,:),ny,ny) * gss)' * gx(:,j);
                
                % Term 24
                tfc = reshape(fyxp,n,ny,nx);
                q(i,j)= q(i,j) + (reshape(tfc(i,:,:),ny,nx) * hss)' * gx(:,j);
                
                % Term 27
                tfc = reshape(fxpyp,n,nx,ny);
                q(i,j)= q(i,j) + ((reshape(tfc(i,:,:),nx,ny) * gx * hss)' * hx(:,j));

                % Term 29
                tfc = reshape(fxpyp,n,nx,ny);
                q(i,j)= q(i,j) + (reshape(tfc(i,:,:),nx,ny) * gss)' * hx(:,j);
                
                % Term 30
                tfc = reshape(fxpy,n,nx,ny);
                q(i,j)= q(i,j) + (reshape(tfc(i,:,:),nx,ny) * gss)' * hx(:,j);
                
                % Term 33
                tfc = reshape(fxpxp,n,nx,nx);
                q(i,j)= q(i,j) + (reshape(tfc(i,:,:),nx,nx) * hss)' * hx(:,j);

            for k = 1:ne
                % Term 1
                tfc = reshape(fypypyp,n,ny,ny,ny);
                t=1;
                for t=1:ny;
                    if t==1;
                        tmat=(reshape(tfc(i,t,:,:),ny,ny)) * gx * eta(:,k);
                     else
                        tmat=[tmat ((reshape(tfc(i,t,:,:),ny,ny)) * gx * eta(:,k))];
                     end
                end
                q(i,j)= q(i,j) + (tmat' * gx * eta(:,k))' * gx * hx(:,j);
           
                % Term 2
                tfc = reshape(fypypxp,n,ny,ny,nx);
                t=1;
                for t=1:ny;
                    if t==1;
                         tmat=reshape(tfc(i,t,:,:),ny,nx) * eta(:,k);
                     else
                         tmat=[tmat (reshape(tfc(i,t,:,:),ny,nx) * eta(:,k))];
                     end
                end
                q(i,j)= q(i,j) + ((tmat'* gx * eta(:,k))' * gx * hx(:,j));
                
               % Term 4
               tfc = reshape(fypyp,n,ny,ny);
               t=1;
               for t=1:ny;
                    if t==1;
                         tmat=(reshape(gxx(t,:,:),nx,nx)) * eta(:,k);
                     else
                         tmat=[tmat ((reshape(gxx(t,:,:),nx,nx)) * eta(:,k))];
                     end
                end
                tmat = tmat' * eta(:,k);
                q(i,j)= q(i,j) + (reshape(tfc(i,:,:),ny,ny) * tmat)' * gx * hx(:,j);
                
               % Term 5
                tfc = reshape(fypyp,n,ny,ny);
                t=1;
                for t=1:ny;
                    if t==1;
                         tmat=(reshape(gxx(t,:,:),nx,nx)) * eta(:,k);
                     else
                         tmat=[tmat ((reshape(gxx(t,:,:),nx,nx)) * eta(:,k))];
                     end
                end
                tmat = tmat' * hx(:,j);
                q(i,j)= q(i,j) + (reshape(tfc(i,:,:),ny,ny) * gx * eta(:,k))' * tmat;                
                 
                % Term 9
                tfc = reshape(fypxpyp,n,ny,nx,ny);
                t=1;
                for t=1:ny;
                    if t==1;
                        tmat=(reshape(tfc(i,t,:,:),nx,ny)) * gx * eta(:,k);
                     else
                        tmat=[tmat ((reshape(tfc(i,t,:,:),nx,ny)) * gx * eta(:,k))];
                     end
                end
                q(i,j)= q(i,j) + (tmat' * eta(:,k))' * gx * hx(:,j);

                % Term 10
                tfc = reshape(fypxpxp,n,ny,nx,nx);
                t=1;
                for t=1:ny;
                    if t==1;
                        tmat=(reshape(tfc(i,t,:,:),nx,nx)) * eta(:,k);
                     else
                        tmat=[tmat ((reshape(tfc(i,t,:,:),nx,nx)) * eta(:,k))];
                     end
                end
                q(i,j)= q(i,j) + (tmat' * eta(:,k))' * gx * hx(:,j);
                
                % Term 11
                tfc = reshape(fypxp,n,ny,nx);
                t=1;
                for t=1:ny;
                    if t==1;
                         tmat=(reshape(gxx(t,:,:),nx,nx)) * eta(:,k);
                     else
                         tmat=[tmat ((reshape(gxx(t,:,:),nx,nx)) * eta(:,k))];
                     end
                end
                tmat = tmat' * hx(:,j);
                q(i,j)= q(i,j) + (reshape(tfc(i,:,:),ny,nx) * eta(:,k))' * tmat;
                
                % Term 12
                tfc = reshape(fypyp,n,ny,ny);
                t=1;
                for t=1:ny;
                    if t==1;
                         tmat=(reshape(gxx(t,:,:),nx,nx)) * eta(:,k);
                     else
                         tmat=[tmat ((reshape(gxx(t,:,:),nx,nx)) * eta(:,k))];
                     end
                end
                tmat = tmat' * hx(:,j);
                q(i,j)= q(i,j) + (reshape(tfc(i,:,:),ny,ny) * gx * eta(:,k))' * tmat;

                % Term 13
                tfc = reshape(fypxp,n,ny,nx);
                t=1;
                for t=1:ny;
                    if t==1;
                         tmat=(reshape(gxx(t,:,:),nx,nx)) * eta(:,k);
                     else
                         tmat=[tmat ((reshape(gxx(t,:,:),nx,nx)) * eta(:,k))];
                     end
                end
                tmat = tmat' * hx(:,j);
                q(i,j)= q(i,j) + (reshape(tfc(i,:,:),ny,nx) * eta(:,k))' * tmat;
               
               % Term 15
               tfc = reshape(fyp,n,ny);
               t = 1;
               for t=1:ny;
                   m=1;
                   for m=1:nx;
                       if m==1;
                           tmat=((reshape(gxxx(t,m,:,:),nx,nx)) * eta(:,k));
                       else
                           tmat=[tmat ((reshape(gxxx(t,m,:,:),nx,nx)) * eta(:,k))];
                       end
                   end
                   if t==1;
                       bmat = shiftdim(tmat,-1);  
                   else
                       bmat = [bmat; shiftdim(tmat,-1)];
                   end              
               end
               for t=1:ny;
                    if t==1;
                         tmat=(reshape(bmat(t,:,:),nx,nx)) * eta(:,k);
                     else
                         tmat=[tmat ((reshape(bmat(t,:,:),nx,nx)) * eta(:,k))];
                     end
               end
               tmat = tmat' * hx(:,j);
               q(i,j)= q(i,j) + (reshape(tfc(i,:),ny,1))' * tmat;
               
               % Term 16
                tfc = reshape(fyypyp,n,ny,ny,ny);
                t=1;
                for t=1:ny;
                    if t==1;
                        tmat=((reshape(tfc(i,t,:,:),ny,ny)) * gx * eta(:,k));
                     else
                        tmat=[tmat ((reshape(tfc(i,t,:,:),ny,ny)) * gx * eta(:,k))];
                     end
                end
                q(i,j)= q(i,j) + (tmat' * gx * eta(:,k))' * gx(:,j);
               
               % Term 17
                tfc = reshape(fyypxp,n,ny,ny,nx);
                t=1;
                for t=1:ny;
                    if t==1;
                         tmat=reshape(tfc(i,t,:,:),ny,nx) * eta(:,k);
                     else
                         tmat=[tmat (reshape(tfc(i,t,:,:),ny,nx) * eta(:,k))];
                     end
                end
                q(i,j)= q(i,j) + ((tmat'* gx * eta(:,k))' * gx(:,j));
                 
                % Term 19
                tfc = reshape(fyyp,n,ny,ny);
                t=1;
                for t=1:ny;
                     if t==1;
                         tmat=(reshape(gxx(t,:,:),nx,nx)) * eta(:,k);
                     else
                         tmat=[tmat ((reshape(gxx(t,:,:),nx,nx)) * eta(:,k))];
                     end
                end
                tmat = tmat' * eta(:,k);
                q(i,j)= q(i,j) + (reshape(tfc(i,:,:),ny,ny) * tmat)' * gx(:,j);

                % Term 22
                tfc = reshape(fyxpyp,n,ny,nx,ny);
                t=1;
                for t=1:ny;
                    if t==1;
                         tmat=reshape(tfc(i,t,:,:),nx,ny) * gx * eta(:,k);
                     else
                         tmat=[tmat (reshape(tfc(i,t,:,:),nx,ny) * gx * eta(:,k))];
                     end
                end
                q(i,j)= q(i,j) + ((tmat'* eta(:,k))' * gx(:,j));

                % Term 23
                tfc = reshape(fyxpxp,n,ny,nx,nx);
                t=1;
                for t=1:ny;
                    if t==1;
                         tmat=reshape(tfc(i,t,:,:),nx,nx) * eta(:,k);
                     else
                         tmat=[tmat (reshape(tfc(i,t,:,:),nx,nx) * eta(:,k))];
                     end
                end
                q(i,j)= q(i,j) + ((tmat'* eta(:,k))' * gx(:,j));
 
                % Term 25
                tfc = reshape(fxpypyp,n,nx,ny,ny);
                t=1;
                for t=1:nx;
                    if t==1;
                        tmat=((reshape(tfc(i,t,:,:),ny,ny)) * gx * eta(:,k));
                     else
                        tmat=[tmat ((reshape(tfc(i,t,:,:),ny,ny)) * gx * eta(:,k))];
                     end
                end
                q(i,j)= q(i,j) + (tmat' * gx * eta(:,k))' * hx(:,j);
                
                % Term 26
                tfc = reshape(fxpypxp,n,nx,ny,nx);
                t=1;
                for t=1:nx;
                    if t==1;
                        tmat=((reshape(tfc(i,t,:,:),ny,nx)) * eta(:,k));
                     else
                        tmat=[tmat ((reshape(tfc(i,t,:,:),ny,nx)) * eta(:,k))];
                     end
                end
                q(i,j)= q(i,j) + (tmat' * gx * eta(:,k))' * hx(:,j);
                 
                % Term 28
                tfc = reshape(fxpyp,n,nx,ny);
                t=1;
                for t=1:ny;
                     if t==1;
                         tmat=(reshape(gxx(t,:,:),nx,nx)) * eta(:,k);
                     else
                         tmat=[tmat ((reshape(gxx(t,:,:),nx,nx)) * eta(:,k))];
                     end
                end
                tmat = tmat' * eta(:,k);
                q(i,j)= q(i,j) + (reshape(tfc(i,:,:),nx,ny) * tmat)' * hx(:,j);
 
                % Term 31
                tfc = reshape(fxpxpyp,n,nx,nx,ny);
                t=1;
                for t=1:nx;
                    if t==1;
                         tmat=reshape(tfc(i,t,:,:),nx,ny) * gx * eta(:,k);
                     else
                         tmat=[tmat (reshape(tfc(i,t,:,:),nx,ny) * gx * eta(:,k))];
                     end
                end
                q(i,j)= q(i,j) + ((tmat'* eta(:,k))' * hx(:,j));

                % Term 32
                tfc = reshape(fxpxpxp,n,nx,nx,nx);
                t=1;
                for t=1:nx;
                    if t==1;
                         tmat=reshape(tfc(i,t,:,:),nx,nx) * eta(:,k);
                     else
                         tmat=[tmat (reshape(tfc(i,t,:,:),nx,nx) * eta(:,k))];
                     end
                end
                q(i,j)= q(i,j) + (tmat'* eta(:,k))' * hx(:,j);

            end
      end
end

% Reshape constants
q = permute(q,[2 1]);
q = reshape(q,n*nx,1);


% COMPUTE COEFFICIENTS OF GXSS AND HXSS
ngxss = nx*ny; % elements of gxss
nhxss = nx^2; % elements of hxss
sg = [ny nx]; %size of gxss
sh = [nx nx]; %size of hxss

Q = zeros(n*nx,ngxss+nhxss);

gxss=zeros(sg);
hxss=zeros(sh);
GXSS=zeros(sg);
HXSS=zeros(sh);

t = 0;
for i=1:n
        for j=1:nx
                t = t+1;
                GXSS(:) = kron(ones(nx,1),fyp(i,:)');
                                
                pGXSS = permute(GXSS,[2 1]);
                pGXSS(:) = pGXSS(:) .* kron(ones(ny,1),hx(:,j));
                GXSS=ipermute(pGXSS,[2 1]);
                             
                Q(t,1:ngxss)=GXSS(:)';
                GXSS=0*GXSS;

                HXSS(:,j) = (fyp(i,:) * gx)';
                Q(t,ngxss+1:end)=HXSS(:)';
                HXSS = 0*HXSS;

                GXSS(:,j)=fy(i,:)';
                Q(t,1:ngxss) = Q(t,1:ngxss) + GXSS(:)';
                GXSS = 0*GXSS;

                HXSS(:,j)=fxp(i,:)';
                Q(t,ngxss+1:end) = Q(t,ngxss+1:end) + HXSS(:)';
                HXSS = 0*HXSS;    
        end
end


% SOLVE FOR THIRD-ORDER COEFFICIENTS
cc = -Q\q;
gxss(:)=cc(1:ngxss);
hxss(:) = cc(ngxss+1:end);
