* modified_hank.ipynb looks at the (one asset) HANK notebook from the SSJ repository and offers a more thorough decomposition of what's going on in response to shocks in the interest rate
    * I expedite the portions of the workbook I didn't change and get to the new results, which are striking
* two_asset2.ipynb follows the discussion from before to the two asset case
    * Allowing for borrowing here makes a huge difference. Model is highly sensisitive to these changes (holding everything else constant)   
    * This is in progress, more care is required to deal with new aspects
